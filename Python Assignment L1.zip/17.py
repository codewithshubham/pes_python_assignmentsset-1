x=input("Enter the value of n")
y=[]
for i in range(0,x):
	y.append(input("Enter num : "))
print("Biggest : %d"%max(y))	
print("Smallest : %d"%min(y))	
