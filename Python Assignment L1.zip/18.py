for i in range(0,101):
	print i
for i in range(100,-1):
	print i
count = 100
while count > 0:
	print count
	count=count+1
count = 100
while count < 0:
	print count
	count=count-1	