x=(1,2,3,4,5,6,7,8,9,10)
for i in x:
    print i
    
print x[0:5]
print x*3
y=(11,22,33)
print x+y	