id=[0,1,2,3,4,5,6,7,8,9]
name=["zero ","one ","two ","three ","four ","five ","six ","seven ","eight ","nine "]
for i in name:
	print i
x=input("Enter id : ")
print name[x]
print name[4:10:]
print name[3::]
n=input("enter the value of n")
print name[0]*n
add=id+name
print add
for i in range(0,10)
	print id[i]+" "+name[i]