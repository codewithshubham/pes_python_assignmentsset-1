a = 60
b = 13
c = 0
print c
c = a & b
print c
c = a | b
print c
c = a ^ b
print c 
c = ~a
print c
c = a << b
print c
c = a >> b
print c