for i in range(1,101):
	if i==50:
		break
	if i==10|i==20|i==30|i==40|i==50:
		continue
	if i%2==0:
		print i
	