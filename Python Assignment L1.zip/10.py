a = 60
b = 13
res = 0
print res
res = a & b
print res
res = a / b
print res
res = a * b
print res 
res = a - b
print res
res = a + b
print res